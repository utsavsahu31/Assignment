package com.demo;

public class Car implements Vehical{

	@Override
	public void move() {
		System.out.println("moving in a car");	
	}

}
